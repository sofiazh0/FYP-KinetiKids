import numpy as np
from langchain.docstore.document import Document
from langchain_huggingface import HuggingFaceEmbeddings
from nltk.tokenize import sent_tokenize
from pinecone import Pinecone
import requests
import warnings
from fastapi import FastAPI, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import PyPDF2
import os
from huggingface_hub import InferenceClient
from transformers import pipeline
from datasets import load_dataset
import soundfile as sf
import torch
import re
from pydub import AudioSegment
from fastapi import BackgroundTasks  # Import BackgroundTasks


warnings.filterwarnings("ignore")
API_KEY = "Bearer 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"
pc_api_key = "62fd34a9-fb37-492c-a395-f2e1f39f350f"
embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
pc = Pinecone(api_key=pc_api_key)
API_URL = "HuggingFaceTB/SmolLM2-1.7B-Instruct"
summarizer_model = "https://api-inference.huggingface.co/models/philschmid/bart-large-cnn-samsum"
client = InferenceClient(
	provider="together",
	api_key="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"
)
#client = InferenceClient(api_key="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")
headers = {"Authorization": API_KEY}
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins
    allow_credentials=True,
    allow_methods=["*"],   
    allow_headers=["*"],  
)

chunk_size = 3  
chunk_overlap = 1  


text = """Neural networks, a subset of machine learning, are computational models inspired by the human brain's neural structure. They consist of layers of nodes (neurons) connected by weighted edges, where each node processes input data through an activation function and passes it to the next layer. These networks are primarily used for tasks like classification, regression, and pattern recognition. The most basic form, the feedforward neural network, processes data in one direction from input to output layers. More advanced architectures include convolutional neural networks (CNNs), which excel at image processing by learning spatial hierarchies, and recurrent neural networks (RNNs), designed for sequence data such as time series or natural language. Training a neural network involves adjusting the weights using optimization algorithms like gradient descent, where backpropagation calculates the error gradient to refine these weights, improving the network's predictions. Neural networks, especially deep learning models, require vast amounts of data and computational power, but once trained, they can perform highly complex tasks, from object recognition to language translation, with remarkable accuracy. Their ability to automatically learn features from raw data has made them a cornerstone of modern AI, transforming industries ranging from healthcare to finance by enabling systems to make decisions and predictions based on previously unattainable levels of insight."""

def extract_text_from_pdf(pdf_file):
    pdf_reader = PyPDF2.PdfReader(pdf_file)
    text = ''
    for page_num in range(len(pdf_reader.pages)):
        page = pdf_reader.pages[page_num]
        text += page.extract_text()  
    return text

def tokenizer(text):
    sentences = sent_tokenize(text)
    return sentences

def create_sentence_chunks(sentences, chunk_size, chunk_overlap):
    chunks = []
    
    for i in range(0, len(sentences), chunk_size - chunk_overlap):
        chunk = ' '.join(sentences[i:i + chunk_size])
        chunks.append(chunk)
        if i + chunk_size >= len(sentences):
            break
    
    return chunks

def docer(sentence_chunks):
    documents = [Document(page_content=chunk) for chunk in sentence_chunks]
    return documents


def pad_embedding(embedding, target_dim=512):
    if not isinstance(embedding, np.ndarray):
        embedding = np.array(embedding)
    
    current_dim = embedding.shape[-1]
    if current_dim < target_dim:
        padding = np.zeros(target_dim - current_dim)
        padded_embedding = np.concatenate([embedding, padding])
    else:
        padded_embedding = embedding
    
    return padded_embedding

def extract_embeddings(df):
    all_embeddings = []
    for text in df:
        embedding = embeddings.embed_query(text)
        padded_embedding = pad_embedding(embedding, target_dim=512)
        all_embeddings.append(padded_embedding)
    
    return all_embeddings


def insert_to_vdb(documents, embeddings):

    index = pc.Index(name="fyp-txt-embedding4")
    document_contents = [doc.page_content for doc in documents]
    embeddings_list = [embeddings.embed_query(text) for text in document_contents]

    values = [
        (str(i), emb, {"text": document_contents[i]})  
        for i, emb in enumerate(embeddings_list)
    ]

    index.upsert(vectors=values)
    return index

def get_new_input(query_text, index, embeddings):

    query_embedding = embeddings.embed_query(query_text)
    response = index.query(
        vector=query_embedding,
        top_k=2,  # Number of closest vectors to return
        include_values=True,
        include_metadata=True
    )
    context = ''
    for match in response["matches"]:
        #print(match['metadata']['text'])
        context = context + match['metadata']['text']
    print(context)
    system_prompt = "You are a friendly chatbot who always has a positive attitude. You are here to help customers with their questions. Please keep your answer brief and relevant. If the text is not applicable to the question, reply with 'Not applicable.' If you dont find the answer to my question in the given context, just say 'Not Applicable' and nothing more. Keep your answer very short and to the point. Do not present the thought process of the answer. You need to provide an answer based on the following content: " + context

    messages = [
        {
            "role": "system",
            "content": system_prompt
        },
        {
            "role": "user",
            "content": query_text
        }
    ]

    return messages


def get_new_input_guardian(query_text, index, embeddings):

    query_embedding = embeddings.embed_query(query_text)
    response = index.query(
        vector=query_embedding,
        top_k=1,  # Number of closest vectors to return
        include_values=True,  
        include_metadata=True  
    )
    context = ''
    for match in response["matches"]:
        context = context + match['metadata']['text']

    system_prompt = "You are a friendly chatbot who always has a positive attitude. You are here to help customers with their questions. Please keep your answer brief and relevant. You have to summarize the following content and return a summary. dont forget to discuss all the topics and answers by chatbot. Here is the text to summarize: " + context

    messages = [
        {
            "role": "system",
            "content": system_prompt
        },
        {
            "role": "user",
            "content": query_text
        }
    ]

    return messages

def get_new_output(messages):
    completion = client.chat.completions.create(
        model="deepseek-ai/DeepSeek-R1", 
        messages=messages, 
        max_tokens=500
    )

    return completion.choices[0].message.content


def preprocess_text(text):
    """
    Preprocesses the text to remove extra spaces and fix punctuation spacing.
    """
    # Remove extra spaces
    text = re.sub(r'\s+', ' ', text).strip()
    # Ensure proper spacing around punctuation
    text = re.sub(r'\s([?.!,;:])', r'\1', text)
    return text

def split_text_into_chunks(text, max_length=200):
    """
    Splits the text into chunks of a specified maximum length.
    Ensures chunks are split at spaces for readability.
    """
    words = text.split()
    chunks = []
    current_chunk = []
    current_length = 0

    for word in words:
        if current_length + len(word) + 1 <= max_length:  # +1 for space
            current_chunk.append(word)
            current_length += len(word) + 1
        else:
            chunks.append(" ".join(current_chunk))
            current_chunk = [word]
            current_length = len(word) + 1
    if current_chunk:
        chunks.append(" ".join(current_chunk))
    return chunks

def text_to_speech(text, output_file="speech.wav", max_length=200):
    chunks = split_text_into_chunks(text, max_length)

    synthesiser = pipeline("text-to-speech", "microsoft/speecht5_tts")

    embeddings_dataset = load_dataset("Matthijs/cmu-arctic-xvectors", split="validation")
    speaker_embedding = torch.tensor(embeddings_dataset[7306]["xvector"]).unsqueeze(0)

    audio_segments = []
    for i, chunk in enumerate(chunks):
        #print(f"Processing chunk {i+1}/{len(chunks)}: {chunk}")
        print("Making audio")
        speech = synthesiser(chunk, forward_params={"speaker_embeddings": speaker_embedding})
        temp_file = f"chunk_{i}.wav"
        sf.write(temp_file, speech["audio"], samplerate=speech["sampling_rate"])
        audio_segments.append(AudioSegment.from_file(temp_file))

    final_audio = sum(audio_segments)
    final_audio.export(output_file, format="wav")
    print(f"Final audio saved to {output_file}")

    return output_file

import re

def extract_text_after_last_think(text):
    # Use regex to find the last occurrence of "</think>" and get everything after it
    match = re.search(r"</think>(.*)", text, re.DOTALL)
    return match.group(1).strip() if match else None

def play_audio(text):
    audio_file = text_to_speech(text, max_length=600)

def query_sum(payload):
    response = requests.post(summarizer_model, headers=headers, json=payload)
    return response.json()

def summarizer(text):
    output = query_sum({
        "inputs": text,
    })
    return output[0]['summary_text']

class QueryModel(BaseModel):
    text: str
    query_text: str

@app.post("/process_query/")
async def process_query(query: QueryModel):
    # existing functions
    sentences = tokenizer(query.text)
    sentence_chunks = create_sentence_chunks(sentences, chunk_size, chunk_overlap)
    documents = docer(sentence_chunks)
    document_contents = [doc.page_content for doc in documents]
    x = extract_embeddings(document_contents)
    index = insert_to_vdb(documents, embeddings)
    final_in = get_new_input(query.query_text, index, embeddings)
    outer = get_new_output(final_in)

    return {"response": outer}

@app.post("/process_pdf_query/")
async def upload_pdf(query_text: str = Form(...), pdf_file_name: str = Form(...)):
    pdf_file_path = os.path.join("G:\\FYP Kinetikids\\FYP\\backend", pdf_file_name)  
    pdf_text = extract_text_from_pdf(pdf_file_path)
    sentences = sent_tokenize(pdf_text)
    sentence_chunks = create_sentence_chunks(sentences, chunk_size, chunk_overlap)
    documents = docer(sentence_chunks)
    document_contents = [doc.page_content for doc in documents]
    x = extract_embeddings(document_contents)
    index = insert_to_vdb(documents, embeddings)
    final_in = get_new_input(query_text, index, embeddings)
    outer = get_new_output(final_in)
    outer = extract_text_after_last_think(outer)
    play_audio(outer)
    return {"response": outer}

@app.post("/process_pdf_query_guardian/")
async def upload_pdf(query_text: str = Form(...), pdf_file_name: str = Form(...)):
    pdf_file_path = os.path.join("G:\\FYP Kinetikids\\FYP\\backend", pdf_file_name)  
    pdf_text = extract_text_from_pdf(pdf_file_path)
    outer = summarizer(pdf_text)
    return {"response": outer}

def main():
    import uvicorn
    import nltk
    #nltk.download()
    uvicorn.run(app, host="127.0.0.1", port=8000, reload=False)

if __name__ == "__main__":
    main()