import React from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "./Navbar";
import "./StudentSignupPage.css"; // Import CSS styles
import { Link } from "react-router-dom";

const StudentSignupPage = () => {
  const navigate = useNavigate();

  return (
    <div className="student-signup-page">
      {/* Navbar */}
      <Navbar />

      {/* Main Content */}
      <div className="signup-container">
        {/* Left Section */}
        <div className="signup-left">
          <h2 className="signup-title">Signup Portal</h2>
          <h1 className="student-title">Student</h1>
          <h1 className="mode-title">Mode</h1>
          <p className="signup-text">
            Not a Student? Switch to {" "}
            <Link to="/guardian-mode" className="guardian-link">
            Guardian Mode
            </Link>{" "}
            to continue
          </p>
        </div>

        {/* Right Section - Signup Form */}
        <div className="signup-right">
          <div className="signup-form">
            <input type="text" placeholder="First Name" className="signup-input" />
            <input type="text" placeholder="Last Name" className="signup-input" />
            <input type="email" placeholder="Email Address" className="signup-input" />
            <input type="email" placeholder="Guardian Email" className="signup-input" />
            <input type="text" placeholder="Grade" className="signup-input" />
            <input type="password" placeholder="Password" className="signup-input" />
            <input type="password" placeholder="Re-enter Password" className="signup-input" />
            <button className="signup-button">Signup Now</button>
          </div>
          <p className="login-text">
            {/* Already have an account? <a href="/login">Login Now.</a> */}
            Already have an account?{" "} <Link to="/login">
                              Login Now.
                              </Link>{" "}
          </p>
        </div>
      </div>

      {/* Footer */}
      <footer className="signup-footer">
        <p>© 2024 SparkQuest</p>
      </footer>
    </div>
  );
};

export default StudentSignupPage;
