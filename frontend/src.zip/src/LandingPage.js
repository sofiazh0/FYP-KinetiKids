import React from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for navigation
import Navbar from './Navbar'; // Import the reusable Navbar component
import Typewriter from 'typewriter-effect';
// import ParticleBackground from './ParticleBackground'; // Import the ParticleBackground component
import './LandingPage.css'; // Import a CSS file for styling the landing page

const LandingPage = () => {
  const navigate = useNavigate(); // Initialize the navigate hook

  return (
    <div className="landing-page">
      {/* Reusing the Navbar component */}
      
      {/* <ParticleBackground /> */}
      <Navbar />

      <main className="landing-content">
        <div className="landing-text">
          <h1 className="landing-title">KinetiKids</h1>
          {/* <p className="landing-subtitle">Where Young Minds and Smart Tech Meet.</p> */}
          <div className="typewriter-effect">
            <Typewriter
              options={{
                strings: [
                  "Where Young Minds and Smart Tech Meet.",
                ],
                autoStart: true,
                loop: true,
                delay: 95,
                deleteSpeed: 60,
              }}
            />
          </div>
        </div>
        <div className="landing-buttons">
          {/* Navigate to Home.js for Student Mode */}
          <button className="landing-button" onClick={() => navigate('/student-mode')}>Student Mode</button>

          {/* Navigate to GuardianHome.js for Guardian Mode */}
          <button className="landing-button" onClick={() => navigate('/guardian-mode')}>Guardian Mode</button>
        </div>
      </main>

      {/* <footer className="landing-footer">
        <p>Copyright © 2024 All Rights Reserved</p>
      </footer> */}
    </div>
  );
};

export default LandingPage;
