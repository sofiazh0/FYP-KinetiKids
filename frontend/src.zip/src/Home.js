import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import NavbarHome from './NavbarHome'; // Import the NavbarHome component
import './Home.css'; // Custom styles

function Home() {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate(); // React Router navigation hook

  // Function to toggle the sidebar state
  const handleSidebarToggle = (isOpen) => {
    setSidebarOpen(isOpen);
  };

  return (
    <div className={`Home ${isSidebarOpen ? 'sidebar-active' : ''}`}>
      {/* Navbar with Sidebar toggle functionality */}
      <NavbarHome onSidebarToggle={handleSidebarToggle} />

      {/* Main Section for the homepage content */}
      <div className="home-container">
        <div className="home-left">
          <h1 className="home-title">Making Education Interactive</h1>
          <p className="home-subtitle">
            We aim to create an interactive learning environment for students that helps them enhance their learning experience.
          </p>
          {/* Updated Button to Navigate to About Us Page */}
          <button className="home-button" onClick={() => navigate('/about-us')}>
            About Us
          </button>
        </div>
        <div className="home-right">
          <img src={require('./assets/home-img.png')} alt="Education" className="home-image" />
        </div>
      </div>

      {/* Footer */}
      {/* <footer className="home-footer">
        <p>© 2024 KinetiKids</p>
        <div className="footer-social-icons">
          <a href="#"><i className="fab fa-linkedin"></i></a>
          <a href="#"><i className="fab fa-twitter"></i></a>
          <a href="#"><i className="fab fa-facebook"></i></a>
          <a href="#"><i className="fab fa-instagram"></i></a>
        </div>
      </footer> */}
    </div>
  );
}

export default Home;
