import React from "react";
import { useNavigate} from "react-router-dom"; // Import Link for navigation
import NavbarHome from "./NavbarHome";
import "./CoursesPage.css";

const courses = [
  { id: 1, name: "English", icon: require("./assets/english-icon.png"), path: "/english-page" },
  { id: 2, name: "Maths", icon: require("./assets/maths-icon.png"), path: "/math-page" },
  { id: 3, name: "Science", icon: require("./assets/science-icon.png"), path: "/science-page" }, // Add the path to Science Page
];

const CoursesPage = () => {
  const navigate = useNavigate();

  const handleSelectCourse = (course) => {
    navigate(course.path); // Navigate to specific course or science page
  };

  return (
    <div className="courses-page">
      {/* ✅ Navbar */}
      <NavbarHome />

      {/* ✅ Course Cards */}
      <div className="courses-container">
        {courses.map((course) => (
          <div key={course.id} className="course-card">
            <div className="course-icon">
              <img src={course.icon} alt={course.name} />
            </div>
            <h2>{course.name}</h2>
            <button className="select-btn" onClick={() => handleSelectCourse(course)}>
              Select
            </button>
          </div>
        ))}
      </div>

      {/* ✅ Footer */}
      {/* <footer className="courses-footer">
        <p>© 2024 KinetiKids</p> */}
        {/* <div className="footer-social-icons">
          <a href="#"><i className="fab fa-linkedin"></i></a>
          <a href="#"><i className="fab fa-x-twitter"></i></a>
          <a href="#"><i className="fab fa-facebook"></i></a>
          <a href="#"><i className="fab fa-instagram"></i></a>
        </div> */}
      {/* </footer> */}
    </div>
  );
};

export default CoursesPage;
