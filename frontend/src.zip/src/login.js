import React, { useState } from 'react';
import axios from 'axios'; // Import axios
import Navbar from './Navbar'; // Import Navbar
import "./Login.css"; // Ensure Login CSS is applied
import { Link } from "react-router-dom";
import { useNavigate } from 'react-router-dom';

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isGuardian, setIsGuardian] = useState(false); 
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  // Handle Login
  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await axios.post('http://127.0.0.1:8000/login/', {
        email,
        password,
        is_guardian: isGuardian
      });

      alert("Login successful!");
      if (response.data.role === "student") {
        sessionStorage.setItem("student", JSON.stringify(response.data.user));
        navigate('/home');
      } else {
        sessionStorage.setItem("guardian", JSON.stringify(response.data.user));
        navigate("/guardian");
      }
    } catch (err) {
      console.error('Login Failed:', err);
      setError("Invalid email or password");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <Navbar />
      {/* Left Side */}
      <div className="login-left">
        {/* <h1 className="home-title">Making Education Interactive</h1> */}
        
        {/* Login Form */}
        <div className="login-box">
          <h2>Welcome Back</h2>

          <form className="login-form" onSubmit={handleLogin}>
            <div className="input-group">
              <i className="fas fa-user"></i>
              <input
                type="email"
                placeholder="Username"
                className="login-input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="input-group">
              <i className="fas fa-lock"></i>
              <input
                type="password"
                placeholder="Password"
                className="login-input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <p className="login-text-next">
                  Not a user?{" "}
                  <Link to="/student-signup" class='guardian-link-next'>
                  Signup Now
                  </Link>{" "}
                  
            </p>
            {/* <p className="forgot-password">Forget password?</p> */}

            {/* Guardian Checkbox */}
            <div className="guardian-checkbox">
              <input
                type="checkbox"
                checked={isGuardian}
                onChange={(e) => setIsGuardian(e.target.checked)}
              />
              <label>Are you a guardian?</label>
            </div>

            <button type="submit" className="login-button">
              {loading ? "Logging in..." : "Login Now"}
            </button>

            {error && <p className="error-message">{error}</p>}
          </form>
        </div>
      </div>

      {/* Right Side (Image) */}
      <div className="signup-left">
                <h2 className="signup-title">Login Portal</h2>
                <h1 className="guardian-title">Student</h1>
                <h1 className="mode-title">Mode</h1>
                <p className="signup-text">
                  Not a Student? Switch to{" "}
                  <Link to="/guardian-mode" className="guardian-link">
                  Guardian Mode
                  </Link>{" "}
                  to continue
                </p>
              </div>
    </div>
  );
}

export default Login;
