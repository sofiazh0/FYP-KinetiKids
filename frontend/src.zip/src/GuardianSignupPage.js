import React from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "./Navbar";
import "./GuardianSignupPage.css"; // Import CSS styles

const GuardianSignupPage = () => {
  const navigate = useNavigate();

  return (
    <div className="guardian-signup-page">
      {/* Navbar */}
      <Navbar />

      {/* Main Content */}
      <div className="signup-container">
        {/* Left Section - Signup Form */}
        <div className="signup-right">
          <div className="signup-form">
            <input type="text" placeholder="First Name" className="signup-input" />
            <input type="text" placeholder="Last Name" className="signup-input" />
            <input type="text" placeholder="Username" className="signup-input" />
            <input type="email" placeholder="Email Address" className="signup-input" />
            <input type="password" placeholder="Password" className="signup-input" />
            <input type="password" placeholder="Re-enter Password" className="signup-input" />
            <button className="signup-button">Signup Now</button>
          </div>
          <p className="login-text">
            Already have an account? <a href="/#/logincopy">Login Now.</a>
          </p>
        </div>

        {/* Right Section */}
        <div className="signup-left">
          <h2 className="signup-title">Signup Portal</h2>
          <h1 className="guardian-title">Guardian</h1>
          <h1 className="mode-title">Mode</h1>
          <p className="signup-text">
            Not a Guardian? Switch to{" "}
            <a href="/student-signup" className="student-link">
              Student Mode
            </a>{" "}
            to continue
          </p>
        </div>
      </div>

      {/* Footer */}
      {/* <footer className="signup-footer">
        <p>© 2024 KinetiKids</p>
      </footer> */}
    </div>
  );
};

export default GuardianSignupPage;
