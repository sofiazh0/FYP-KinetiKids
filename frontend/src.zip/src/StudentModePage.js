import React from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "./Navbar"; // Import Navbar
import "./StudentModePage.css"; // Import CSS for styling
import { Link } from "react-router-dom";

const StudentModePage = () => {
  const navigate = useNavigate(); // React Router navigation hook

  return (
    <div className="student-mode-page">
      {/* Navbar */}
      <Navbar />

      {/* Main Content */}
      <div className="student-mode-container">
        {/* Left Section */}
        <div className="student-mode-left">
          <button className="student-mode-button">Student Mode</button>
          <p className="student-mode-text">
            Not a Student? Switch to{" "}
            <Link to="/guardian-mode" className="guardian-link">
              Guardian Mode
            </Link>{" "}
            to continue
          </p>
        </div>

        {/* Right Section - Login & Signup Options */}
        <div className="student-mode-right">
          <button className="login-button" onClick={() => navigate("/login")}>
            Login
          </button>
          <p className="option-text">Have an existing account?</p>

          {/* Navigate to Student Signup Page */}
          <button className="signup-button" onClick={() => navigate("/student-signup")}>
            Signup
          </button>
          <p className="option-text">Make a new account!</p>
        </div>
      </div>
    </div>
  );
};

export default StudentModePage;
