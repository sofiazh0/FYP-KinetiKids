import React from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "./Navbar"; // Import Navbar
import "./GuardianModePage.css"; // Import CSS for styling
import { Link } from "react-router-dom";

const GuardianModePage = () => {
  const navigate = useNavigate(); // React Router navigation hook

  return (
    <div className="guardian-mode-page">
      {/* Navbar */}
      <Navbar />

      {/* Main Content */}
      <div className="guardian-mode-container">
        {/* Left Section - Login & Signup Options */}
        <div className="guardian-mode-left">
          <button className="login-button" onClick={() => navigate("/logincopy")}>
            Login
          </button>
          <p className="option-text">Have an existing account?</p>

          {/* Navigate to Guardian Signup Page */}
          <button className="signup-button" onClick={() => navigate("/guardian-signup")}>Signup</button>
          <p className="option-text">Make a new account!</p>
        </div>

        {/* Right Section */}
        <div className="guardian-mode-right">
          <button className="guardian-mode-button">Guardian Mode</button>
          <p className="guardian-mode-text">
            Not a Guardian? Switch to{" "}
            <Link to="/student-mode" className="student-link">
            Student Mode
            </Link>{" "}
            to continue
          </p>
        </div>
      </div>
    </div>
  );
};

export default GuardianModePage;
